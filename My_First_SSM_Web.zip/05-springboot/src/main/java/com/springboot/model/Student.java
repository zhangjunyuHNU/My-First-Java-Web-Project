package com.springboot.model;

import java.util.Date;
import java.util.Set;

import com.springboot.model.Score;

public class Student {
    private Integer id;

    private String stuNo;

    private String stuName;

    private String sex;

    private Date birth;

    private String department;

    private String addr;

    private Set<Score> score;

    public Set<Score> getScore() {
        return score;
    }

    public void setScore(Set<Score> score) {
        this.score = score;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStuNo() {
        return stuNo;
    }

    public void setStuNo(String stuNo) {
        this.stuNo = stuNo;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    @Override
    public String toString() {
        return "Student[" +
                "id=" + id + ", stuNo=" + stuNo  + ", stuName=" + stuName  +
                ", sex=" + sex  + ", birth=" + birth + ", department=" + department  +
                ", addr=" + addr   +
                score+ ']';
    }
}