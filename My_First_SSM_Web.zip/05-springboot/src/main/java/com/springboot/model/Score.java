package com.springboot.model;

public class Score {
    private Integer scoreId;

    private String stuNo;

    private String cName;

    private Integer grade;

    public Integer getScoreId() {
        return scoreId;
    }

    public void setScoreId(Integer scoreId) {
        this.scoreId = scoreId;
    }

    public String getStuNo() {
        return stuNo;
    }

    public void setStuNo(String stuNo) {
        this.stuNo = stuNo;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Score[" +
                "scoreId=" + scoreId +
                ", stuNo=" + stuNo  +
                ", cName=" + cName  +
                ", grade=" + grade +
                ']';
    }
}