package com.springboot.web;

import com.springboot.service.StudentService;
import com.springboot.model.Student;
import com.springboot.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Controller
public class StudentController {

    @Autowired
    StudentService studentService;

    @Autowired
    ScoreService scoreService;
//根据ID查找学生
    @RequestMapping(value = "/select")
    public @ResponseBody
    Object select(Integer id) {
        Student student = studentService.queryStudentById(id);
        return student.toString();
    }

    //查找所有学生
    @RequestMapping(value = "queryall")
    public  @ResponseBody
    Object queryall(){
         List<Student> students = studentService.queryAllStudent();
         return students.toString();
    }

    //根据ID删除学生
    @RequestMapping(value = "/delete")
    public @ResponseBody
    Object delete(Integer id){
        int i = studentService.deleteById(id);
        return "成功删除编号为: "+id+"的学生";
    }
//根据ID增加学生
    @RequestMapping(value = "/insert")
    public @ResponseBody Object insert(Integer id, String stu_no, String name, String sex,
                                       Date birth,String department, String addr) {
        Student student = new Student();
        student.setId(id);
        student.setStuName(name);
        student.setStuNo(stu_no);
        student.setSex(sex);
        student.setBirth(birth);
        student.setDepartment(department);
        student.setAddr(addr);
        int updateCount = studentService.insertStudentSelective(student);
        return "增加成功："+student.toString();
    }

    //根据ID修改学生
    @RequestMapping(value = "/update")
    public @ResponseBody Object updata(Integer id,String stu_no, String name, String sex,
                                       Date birth,String department, String addr){
        Student student = new Student();
        student.setId(id);
        student.setStuName(name);
        student.setStuNo(stu_no);
        student.setSex(sex);
        student.setBirth(birth);
        student.setDepartment(department);
        student.setAddr(addr);
        int updatecount = studentService.updateStudentByIdSelective(student);
        student=studentService.queryStudentById(id);
        return "修改成功："+student.toString();
    }
}