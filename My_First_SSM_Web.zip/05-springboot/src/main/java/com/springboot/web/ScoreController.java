package com.springboot.web;

import com.springboot.model.Score;
import com.springboot.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller
public class ScoreController {

    @Autowired
    ScoreService scoreService;

    //根据ID查找分数
    @RequestMapping(value = "/score/select")
    public @ResponseBody
    Object select(Integer id) {
        Score score = scoreService.queryScoreById(id);
        return score;
    }
    //根据ID删除分数
    @RequestMapping(value = "/score/delete")
    public @ResponseBody
    Object delete(Integer id){
        int i = scoreService.deleteById(id);
        return "成功删除编号为: "+id+"的分数信息";
    }
    //插入
    @RequestMapping(value = "/score/insert")
    public @ResponseBody Object insert(Integer id,String stu_no,String name,Integer grade) {
        Score score = new Score();
        score.setScoreId(id);
        score.setStuNo(stu_no);
        score.setcName(name);
        score.setGrade(grade);
        int updateCount = scoreService.insertScoreSelective(score);
        return "增加成功："+score.toString();
    }

    //根据ID修改学生
    @RequestMapping(value = "/score/update")
    public @ResponseBody Object updata(Integer id,String stu_no,String name,Integer grade){
        Score score = new Score();
        score.setScoreId(id);
        score.setStuNo(stu_no);
        score.setcName(name);
        score.setGrade(grade);
        int updatecount = scoreService.updateScoreByIdSelective(score);
        return "修改成功："+score.toString();
    }
}
