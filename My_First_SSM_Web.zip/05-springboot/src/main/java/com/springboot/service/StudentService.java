package com.springboot.service;

import com.springboot.model.Student;

import java.util.List;
import java.util.Set;

public interface StudentService {
    Student queryStudentById(Integer id);
    List<Student> queryAllStudent();
    int deleteById(Integer id);
    int insertStudentSelective(Student record);
    int updateStudentByIdSelective(Student record);
}
