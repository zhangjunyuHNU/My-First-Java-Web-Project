package com.springboot.service.impl;

import com.springboot.mapper.ScoreMapper;
import com.springboot.model.Score;
import com.springboot.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ScoreServiceImpl implements ScoreService {
    @Autowired
    private ScoreMapper scoreMapper;

    //查找
    @Override
    public Score queryScoreById(Integer id) {
        return scoreMapper.selectByPrimaryKey(id);
    }
    //删除
    @Override
    public int deleteById(Integer id) {
        return scoreMapper.deleteByPrimaryKey(id);
    }
    //插入
    @Override
    public int insertScoreSelective(Score score) {
        int i=scoreMapper.insertSelective(score);
        return i;
    }
    //更新

    @Override
    public int updateScoreByIdSelective(Score score) {
        int i = scoreMapper.updateByPrimaryKeySelective(score);
        return i;
    }
}
