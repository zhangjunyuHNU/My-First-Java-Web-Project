package com.springboot.service;

import com.springboot.model.Score;
import com.springboot.model.Student;

public interface ScoreService {
    Score queryScoreById(Integer id);
    int deleteById(Integer id);
    int insertScoreSelective(Score record);
    int updateScoreByIdSelective(Score record);
}
