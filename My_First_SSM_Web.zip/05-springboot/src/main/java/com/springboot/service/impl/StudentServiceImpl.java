package com.springboot.service.impl;
import com.springboot.mapper.StudentMapper;
import com.springboot.model.Student;
import com.springboot.mapper.ScoreMapper;
import com.springboot.model.Score;
import com.springboot.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;


@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentMapper studentMapper;

    //查找所有学生
    public List<Student> queryAllStudent(){return studentMapper.selectAllStudent();}

    //通过ID查找
    @Override
    public Student queryStudentById(Integer id) {
        return studentMapper.selectByPrimaryKey(id);
    }

    //通过ID删除
    @Override
    public int deleteById(Integer id) {
        return studentMapper.deleteByPrimaryKey(id);
    }

    //插入
    @Override
    public int insertStudentSelective(Student student) {
        int i=studentMapper.insertSelective(student);
        return i;
    }

    //更新
    @Override
    public int updateStudentByIdSelective(Student student) {
        int i = studentMapper.updateByPrimaryKeySelective(student);
        return i;
    }
}